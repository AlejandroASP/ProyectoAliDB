package es.cifpcm.SerafinAlejandroMiAli;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SerafinAlejandroMiAliApplicationTests {

	@Test
	void contextLoads() {
	}

}
