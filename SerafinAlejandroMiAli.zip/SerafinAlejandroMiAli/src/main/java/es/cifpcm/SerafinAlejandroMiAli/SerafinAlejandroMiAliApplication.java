package es.cifpcm.SerafinAlejandroMiAli;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SerafinAlejandroMiAliApplication {

	public static void main(String[] args) {
		SpringApplication.run(SerafinAlejandroMiAliApplication.class, args);
	}

}
