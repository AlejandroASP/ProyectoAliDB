package es.cifpcm.SerafinAlejandroMiAli.model;

public class Filter {
    private String productName;
    private float productPrice;
    private String productPicture;
    private int productStock;
    private int idMunicipio;
    private int idProvincia;
}
